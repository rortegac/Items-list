var mostrarpopup = function(ventana, clase){
 var dialog = $( "#dialog-add-book" ).dialog({
	autoOpen: false,
	height: 400,
	width: 600,
	modal: true,
	buttons: {
		//"Create an account": addUser,
		Cancel: function() {
			dialog.dialog( "close" );
		}		
	},
	close: function() {
		form[ 0 ].reset();
		//allFields.removeClass( "ui-state-error" );
	}
});

dialog.dialog('open');

}